%% Kevyt harjoitustyö

%%
close all
clearvars
clc

load("field.mat")

% normitettu vektorikenttä joka tehtävänannossa oli pyydetty
figure
quiver(X,Y,U,V)

[row,col] = find( isnan(U) == 1 );
U(row,col) = 0;
V(row,col) = 0;

%
U_N = zeros(size(U));
V_N = zeros(size(V));

for j = 1:size(U,1)

    for i = 1:size(U,2)

        U_N(i,j) = U(i,j)./norm( [U(i,j),V(i,j)]' );
        V_N(i,j) = V(i,j)./norm( [U(i,j),V(i,j)]' );

    end
end

figure
hold on
quiver(X,Y,U_N,V_N)

% samaan kuvaan muutama ympyrä piirretty havainnollistamiseksi millaisissa
% alueissa divergenssi pyritään määrittämään lähteen voimakkuuden selville
% saamiseksi

x0 = 0;
y0 = 0;
r = [0.1 0.25 0.5]';

theta1 = 0:pi/50:2*pi;
xunit = r .* cos(theta1) + x0;
yunit = r .* sin(theta1) + y0;
plot(xunit', yunit');

axis tight


%%
F1 = @(x,y) interp2(X,Y,U,x,y);
F2 = @(x,y) interp2(X,Y,V,x,y);

j = 200;
r = linspace(0.1,1,j);

phi = [];
for i = 1:length(r);

x = @(theta) r(i).*cos(theta);
y = @(theta) r(i).*sin(theta);

% ds = sqrt( (dx)^2 + (dy)^2 ) 
% dx/dtheta = Dr*cos(theta)
% dy/dtheta = Dr*sin(theta)

dtheta = 1;
ds = @(theta) sqrt( (r(i).*(-sin(theta)).*dtheta).^2 + (r(i).*(cos(theta)).*dtheta).^2 );

F = @(theta) [F1(x(theta),y(theta));F2(x(theta),y(theta))];

theta_min = 0;
theta_max = 2*pi;

% C: (x-x0)^2 + (y-y0)^2 = r^2, gradC = 2(x-x0)i + 2(y-y0)j, N_hat = [2(x-x0) / 2sqrt((x-x0) + (y-y0)) ; 2(y-y0) / 2sqrt((x-x0) + (y-y0))]

N_hat = @(theta) [2*x(theta) ./ (2*sqrt(x(theta).^2 + y(theta).^2)) ; 2*(y(theta)) ./ (2*sqrt(x(theta).^2 + y(theta).^2))];

inputObj = struct();

inputObj.F = F;
inputObj.N_hat = N_hat;
inputObj.ds = ds;


%%
phi(end+1) = integral( @(theta) divergenceIntegral( theta, inputObj),theta_min,theta_max);


end

% divergenssin oletusarvojen jakauma
figure
histogram(phi)

%%
function divF = divergenceIntegral( theta, inputObj )

F = inputObj.F;
N_hat = inputObj.N_hat;
ds = inputObj.ds;

Ft = F(theta);
nt = N_hat(theta);
dst = ds(theta);

divF = dot(Ft,nt.*dst);

end